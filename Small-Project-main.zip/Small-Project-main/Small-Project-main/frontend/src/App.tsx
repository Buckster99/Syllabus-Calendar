import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import { Calendar, Book, Plus, CheckCircle, Clock, AlertCircle, Home } from 'lucide-react';
import './App.css';

// Types
interface Syllabus {
  id: string;
  title: string;
  course_code: string;
  description: string;
  instructor: string;
  semester: string;
  year: number;
  created_at: string;
  updated_at: string;
}

interface Assignment {
  id: string;
  title: string;
  description: string;
  due_date: string;
  syllabus_id: string;
  course_code: string;
  completed: boolean;
  created_at: string;
  updated_at: string;
}

interface DashboardData {
  total_syllabi: number;
  total_assignments: number;
  completed_assignments: number;
  pending_assignments: number;
  upcoming_assignments: Assignment[];
  overdue_assignments: Assignment[];
}

// Local Storage Keys
const SYLLABI_KEY = 'syllabi';
const ASSIGNMENTS_KEY = 'assignments';

// Utility functions for local storage
const saveToLocalStorage = (key: string, data: any) => {
  localStorage.setItem(key, JSON.stringify(data));
};

const getFromLocalStorage = (key: string) => {
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
};

const generateId = () => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

// Navigation Component
const Navigation: React.FC = () => {
  const location = useLocation();
  
  const navItems = [
    { path: '/', label: 'Dashboard', icon: Home },
    { path: '/syllabi', label: 'Syllabi', icon: Book },
    { path: '/calendar', label: 'Calendar', icon: Calendar },
  ];

  return (
    <nav className="bg-white shadow-sm border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <Book className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">SyllabusCalendar</span>
            </div>
            <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                      isActive
                        ? 'border-blue-500 text-blue-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    <Icon className="h-4 w-4 mr-2" />
                    {item.label}
                  </Link>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

// Dashboard Component
const Dashboard: React.FC<{
  syllabi: Syllabus[];
  assignments: Assignment[];
}> = ({ syllabi, assignments }) => {
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);

  useEffect(() => {
    calculateDashboardData();
  }, [syllabi, assignments]);

  const calculateDashboardData = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const completed = assignments.filter(a => a.completed);
    const pending = assignments.filter(a => !a.completed);
    
    const upcoming: Assignment[] = [];
    const overdue: Assignment[] = [];

    assignments.forEach(assignment => {
      const dueDate = new Date(assignment.due_date);
      dueDate.setHours(0, 0, 0, 0);
      
      if (!assignment.completed && dueDate < today) {
        overdue.push(assignment);
      } else if (dueDate >= today) {
        upcoming.push(assignment);
      }
    });

    const data: DashboardData = {
      total_syllabi: syllabi.length,
      total_assignments: assignments.length,
      completed_assignments: completed.length,
      pending_assignments: pending.length,
      upcoming_assignments: upcoming.sort((a, b) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime()).slice(0, 5),
      overdue_assignments: overdue.sort((a, b) => new Date(b.due_date).getTime() - new Date(a.due_date).getTime()).slice(0, 5)
    };

    setDashboardData(data);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (!dashboardData) {
    return <div className="flex justify-center items-center h-64">Loading...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600">Overview of your courses and assignments</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <Book className="h-8 w-8 text-blue-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Syllabi</p>
              <p className="text-2xl font-bold text-gray-900">{dashboardData.total_syllabi}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <Clock className="h-8 w-8 text-yellow-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Pending</p>
              <p className="text-2xl font-bold text-gray-900">{dashboardData.pending_assignments}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <CheckCircle className="h-8 w-8 text-green-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Completed</p>
              <p className="text-2xl font-bold text-gray-900">{dashboardData.completed_assignments}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <AlertCircle className="h-8 w-8 text-red-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Overdue</p>
              <p className="text-2xl font-bold text-gray-900">{dashboardData.overdue_assignments.length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Upcoming and Overdue Assignments */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow">
          <div className="px-6 py-4 border-b">
            <h2 className="text-lg font-semibold text-gray-900">Upcoming Assignments</h2>
          </div>
          <div className="p-6">
            {dashboardData.upcoming_assignments.length === 0 ? (
              <p className="text-gray-500">No upcoming assignments</p>
            ) : (
              <div className="space-y-4">
                {dashboardData.upcoming_assignments.map((assignment) => (
                  <div key={assignment.id} className="border rounded-lg p-4">
                    <h3 className="font-medium text-gray-900">{assignment.title}</h3>
                    <p className="text-sm text-gray-600">{assignment.course_code}</p>
                    <p className="text-sm text-blue-600 mt-1">Due: {formatDate(assignment.due_date)}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow">
          <div className="px-6 py-4 border-b">
            <h2 className="text-lg font-semibold text-gray-900">Overdue Assignments</h2>
          </div>
          <div className="p-6">
            {dashboardData.overdue_assignments.length === 0 ? (
              <p className="text-gray-500">No overdue assignments</p>
            ) : (
              <div className="space-y-4">
                {dashboardData.overdue_assignments.map((assignment) => (
                  <div key={assignment.id} className="border border-red-200 rounded-lg p-4 bg-red-50">
                    <h3 className="font-medium text-gray-900">{assignment.title}</h3>
                    <p className="text-sm text-gray-600">{assignment.course_code}</p>
                    <p className="text-sm text-red-600 mt-1">Due: {formatDate(assignment.due_date)}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// Syllabi Component
const Syllabi: React.FC<{
  syllabi: Syllabus[];
  assignments: Assignment[];
  onSyllabusCreate: (syllabus: Omit<Syllabus, 'id' | 'created_at' | 'updated_at'>) => void;
  onSyllabusUpdate: (id: string, syllabus: Partial<Syllabus>) => void;
  onSyllabusDelete: (id: string) => void;
  onAssignmentCreate: (assignment: Omit<Assignment, 'id' | 'created_at' | 'updated_at'>) => void;
  onAssignmentToggle: (id: string) => void;
}> = ({ syllabi, assignments, onSyllabusCreate, onSyllabusUpdate, onSyllabusDelete, onAssignmentCreate, onAssignmentToggle }) => {
  const [showSyllabusForm, setShowSyllabusForm] = useState(false);
  const [showAssignmentForm, setShowAssignmentForm] = useState(false);
  const [editingSyllabus, setEditingSyllabus] = useState<Syllabus | null>(null);

  const [syllabusForm, setSyllabusForm] = useState({
    title: '',
    course_code: '',
    description: '',
    instructor: '',
    semester: '',
    year: new Date().getFullYear()
  });

  const [assignmentForm, setAssignmentForm] = useState({
    title: '',
    description: '',
    due_date: '',
    syllabus_id: '',
    course_code: ''
  });

  const handleSyllabusSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingSyllabus) {
      onSyllabusUpdate(editingSyllabus.id, syllabusForm);
    } else {
      onSyllabusCreate(syllabusForm);
    }
    setShowSyllabusForm(false);
    setEditingSyllabus(null);
    resetSyllabusForm();
  };

  const handleAssignmentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAssignmentCreate({
      ...assignmentForm,
      completed: false
    });
    setShowAssignmentForm(false);
    resetAssignmentForm();
  };

  const resetSyllabusForm = () => {
    setSyllabusForm({
      title: '',
      course_code: '',
      description: '',
      instructor: '',
      semester: '',
      year: new Date().getFullYear()
    });
  };

  const resetAssignmentForm = () => {
    setAssignmentForm({
      title: '',
      description: '',
      due_date: '',
      syllabus_id: '',
      course_code: ''
    });
  };

  const editSyllabus = (syllabus: Syllabus) => {
    setEditingSyllabus(syllabus);
    setSyllabusForm({
      title: syllabus.title,
      course_code: syllabus.course_code,
      description: syllabus.description,
      instructor: syllabus.instructor,
      semester: syllabus.semester,
      year: syllabus.year
    });
    setShowSyllabusForm(true);
  };

  const deleteSyllabus = (id: string) => {
    if (window.confirm('Are you sure you want to delete this syllabus and all its assignments?')) {
      onSyllabusDelete(id);
    }
  };

  const getAssignmentsForSyllabus = (syllabusId: string) => {
    return assignments.filter(assignment => assignment.syllabus_id === syllabusId);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Syllabi</h1>
          <p className="text-gray-600">Manage your course syllabi and assignments</p>
        </div>
        <div className="space-x-4">
          <button
            onClick={() => setShowAssignmentForm(true)}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Assignment
          </button>
          <button
            onClick={() => setShowSyllabusForm(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Syllabus
          </button>
        </div>
      </div>

      {/* Syllabus Form Modal */}
      {showSyllabusForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">
              {editingSyllabus ? 'Edit Syllabus' : 'Add New Syllabus'}
            </h2>
            <form onSubmit={handleSyllabusSubmit}>
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="Course Title"
                  value={syllabusForm.title}
                  onChange={(e) => setSyllabusForm({...syllabusForm, title: e.target.value})}
                  className="w-full p-3 border border-gray-300 rounded-lg"
                  required
                />
                <input
                  type="text"
                  placeholder="Course Code"
                  value={syllabusForm.course_code}
                  onChange={(e) => setSyllabusForm({...syllabusForm, course_code: e.target.value})}
                  className="w-full p-3 border border-gray-300 rounded-lg"
                  required
                />
                <textarea
                  placeholder="Description"
                  value={syllabusForm.description}
                  onChange={(e) => setSyllabusForm({...syllabusForm, description: e.target.value})}
                  className="w-full p-3 border border-gray-300 rounded-lg h-24"
                  required
                />
                <input
                  type="text"
                  placeholder="Instructor"
                  value={syllabusForm.instructor}
                  onChange={(e) => setSyllabusForm({...syllabusForm, instructor: e.target.value})}
                  className="w-full p-3 border border-gray-300 rounded-lg"
                  required
                />
                <input
                  type="text"
                  placeholder="Semester (e.g., Fall, Spring)"
                  value={syllabusForm.semester}
                  onChange={(e) => setSyllabusForm({...syllabusForm, semester: e.target.value})}
                  className="w-full p-3 border border-gray-300 rounded-lg"
                  required
                />
                <input
                  type="number"
                  placeholder="Year"
                  value={syllabusForm.year}
                  onChange={(e) => setSyllabusForm({...syllabusForm, year: parseInt(e.target.value)})}
                  className="w-full p-3 border border-gray-300 rounded-lg"
                  required
                />
              </div>
              <div className="flex justify-end space-x-4 mt-6">
                <button
                  type="button"
                  onClick={() => {
                    setShowSyllabusForm(false);
                    setEditingSyllabus(null);
                    resetSyllabusForm();
                  }}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                >
                  {editingSyllabus ? 'Update' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Assignment Form Modal */}
      {showAssignmentForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Add New Assignment</h2>
            <form onSubmit={handleAssignmentSubmit}>
              <div className="space-y-4">
                <select
                  value={assignmentForm.syllabus_id}
                  onChange={(e) => {
                    const selectedSyllabus = syllabi.find(s => s.id === e.target.value);
                    setAssignmentForm({
                      ...assignmentForm,
                      syllabus_id: e.target.value,
                      course_code: selectedSyllabus?.course_code || ''
                    });
                  }}
                  className="w-full p-3 border border-gray-300 rounded-lg"
                  required
                >
                  <option value="">Select Course</option>
                  {syllabi.map((syllabus) => (
                    <option key={syllabus.id} value={syllabus.id}>
                      {syllabus.course_code} - {syllabus.title}
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  placeholder="Assignment Title"
                  value={assignmentForm.title}
                  onChange={(e) => setAssignmentForm({...assignmentForm, title: e.target.value})}
                  className="w-full p-3 border border-gray-300 rounded-lg"
                  required
                />
                <textarea
                  placeholder="Assignment Description"
                  value={assignmentForm.description}
                  onChange={(e) => setAssignmentForm({...assignmentForm, description: e.target.value})}
                  className="w-full p-3 border border-gray-300 rounded-lg h-24"
                  required
                />
                <input
                  type="date"
                  value={assignmentForm.due_date}
                  onChange={(e) => setAssignmentForm({...assignmentForm, due_date: e.target.value})}
                  className="w-full p-3 border border-gray-300 rounded-lg"
                  required
                />
              </div>
              <div className="flex justify-end space-x-4 mt-6">
                <button
                  type="button"
                  onClick={() => {
                    setShowAssignmentForm(false);
                    resetAssignmentForm();
                  }}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700"
                >
                  Create
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Syllabi List */}
      <div className="space-y-6">
        {syllabi.map((syllabus) => {
          const syllabusAssignments = getAssignmentsForSyllabus(syllabus.id);
          return (
            <div key={syllabus.id} className="bg-white rounded-lg shadow">
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">
                      {syllabus.course_code} - {syllabus.title}
                    </h3>
                    <p className="text-gray-600">Instructor: {syllabus.instructor}</p>
                    <p className="text-gray-600">{syllabus.semester} {syllabus.year}</p>
                  </div>
                  <div className="space-x-2">
                    <button
                      onClick={() => editSyllabus(syllabus)}
                      className="text-blue-600 hover:text-blue-800"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => deleteSyllabus(syllabus.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      Delete
                    </button>
                  </div>
                </div>
                <p className="text-gray-700 mb-4">{syllabus.description}</p>

                {/* Assignments for this syllabus */}
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">
                    Assignments ({syllabusAssignments.length})
                  </h4>
                  {syllabusAssignments.length === 0 ? (
                    <p className="text-gray-500">No assignments yet</p>
                  ) : (
                    <div className="space-y-2">
                      {syllabusAssignments.map((assignment) => (
                        <div
                          key={assignment.id}
                          className={`flex items-center justify-between p-3 rounded-lg border ${
                            assignment.completed ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'
                          }`}
                        >
                          <div className="flex items-center">
                            <button
                              onClick={() => onAssignmentToggle(assignment.id)}
                              className={`mr-3 ${
                                assignment.completed ? 'text-green-600' : 'text-gray-400'
                              }`}
                            >
                              <CheckCircle className="h-5 w-5" />
                            </button>
                            <div>
                              <h5 className={`font-medium ${
                                assignment.completed ? 'text-green-800 line-through' : 'text-gray-900'
                              }`}>
                                {assignment.title}
                              </h5>
                              <p className="text-sm text-gray-600">
                                Due: {new Date(assignment.due_date).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {syllabi.length === 0 && (
        <div className="text-center py-12">
          <Book className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No syllabi yet</h3>
          <p className="text-gray-600 mb-4">Get started by creating your first syllabus</p>
          <button
            onClick={() => setShowSyllabusForm(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
          >
            Create Syllabus
          </button>
        </div>
      )}
    </div>
  );
};

// Calendar Component
const CalendarView: React.FC<{
  assignments: Assignment[];
  onAssignmentToggle: (id: string) => void;
}> = ({ assignments, onAssignmentToggle }) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const isOverdue = (dueDate: string) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const due = new Date(dueDate);
    due.setHours(0, 0, 0, 0);
    return due < today;
  };

  const isToday = (dueDate: string) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const due = new Date(dueDate);
    due.setHours(0, 0, 0, 0);
    return due.getTime() === today.getTime();
  };

  const groupedAssignments = assignments.reduce((groups: {[key: string]: Assignment[]}, assignment) => {
    const date = assignment.due_date;
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(assignment);
    return groups;
  }, {});

  const sortedDates = Object.keys(groupedAssignments).sort();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Calendar</h1>
        <p className="text-gray-600">View all your assignments by due date</p>
      </div>

      <div className="space-y-6">
        {sortedDates.map((date) => {
          const dateAssignments = groupedAssignments[date];
          const isDateOverdue = isOverdue(date);
          const isDateToday = isToday(date);

          return (
            <div key={date} className="bg-white rounded-lg shadow">
              <div className={`px-6 py-4 border-b ${
                isDateToday ? 'bg-blue-50 border-blue-200' : 
                isDateOverdue ? 'bg-red-50 border-red-200' : 'border-gray-200'
              }`}>
                <h2 className={`text-lg font-semibold flex items-center ${
                  isDateToday ? 'text-blue-900' : 
                  isDateOverdue ? 'text-red-900' : 'text-gray-900'
                }`}>
                  <Calendar className="h-5 w-5 mr-2" />
                  {formatDate(date)}
                  {isDateToday && <span className="ml-2 text-sm bg-blue-600 text-white px-2 py-1 rounded">Today</span>}
                  {isDateOverdue && <span className="ml-2 text-sm bg-red-600 text-white px-2 py-1 rounded">Overdue</span>}
                </h2>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {dateAssignments.map((assignment) => (
                    <div
                      key={assignment.id}
                      className={`flex items-center justify-between p-4 rounded-lg border ${
                        assignment.completed ? 'bg-green-50 border-green-200' : 
                        isDateOverdue ? 'bg-red-50 border-red-200' :
                        isDateToday ? 'bg-blue-50 border-blue-200' : 'bg-gray-50 border-gray-200'
                      }`}
                    >
                      <div className="flex items-center">
                        <button
                          onClick={() => onAssignmentToggle(assignment.id)}
                          className={`mr-4 ${
                            assignment.completed ? 'text-green-600' : 'text-gray-400'
                          }`}
                        >
                          <CheckCircle className="h-6 w-6" />
                        </button>
                        <div>
                          <h3 className={`font-medium ${
                            assignment.completed ? 'text-green-800 line-through' : 'text-gray-900'
                          }`}>
                            {assignment.title}
                          </h3>
                          <p className="text-sm text-gray-600">{assignment.course_code}</p>
                          <p className="text-sm text-gray-600 mt-1">{assignment.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center">
                        {isDateOverdue && !assignment.completed && (
                          <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
                        )}
                        {isDateToday && !assignment.completed && (
                          <Clock className="h-5 w-5 text-blue-500 mr-2" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {assignments.length === 0 && (
        <div className="text-center py-12">
          <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No assignments yet</h3>
          <p className="text-gray-600 mb-4">Create some syllabi and add assignments to see them here</p>
        </div>
      )}
    </div>
  );
};

// Main App Component
const App: React.FC = () => {
  const [syllabi, setSyllabi] = useState<Syllabus[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);

  // Load data from localStorage on component mount
  useEffect(() => {
    const storedSyllabi = getFromLocalStorage(SYLLABI_KEY);
    const storedAssignments = getFromLocalStorage(ASSIGNMENTS_KEY);
    setSyllabi(storedSyllabi);
    setAssignments(storedAssignments);
  }, []);

  // Save to localStorage whenever data changes
  useEffect(() => {
    saveToLocalStorage(SYLLABI_KEY, syllabi);
  }, [syllabi]);

  useEffect(() => {
    saveToLocalStorage(ASSIGNMENTS_KEY, assignments);
  }, [assignments]);

  const handleSyllabusCreate = (syllabusData: Omit<Syllabus, 'id' | 'created_at' | 'updated_at'>) => {
    const now = new Date().toISOString();
    const newSyllabus: Syllabus = {
      ...syllabusData,
      id: generateId(),
      created_at: now,
      updated_at: now
    };
    setSyllabi(prev => [...prev, newSyllabus]);
  };

  const handleSyllabusUpdate = (id: string, updates: Partial<Syllabus>) => {
    setSyllabi(prev => prev.map(syllabus => 
      syllabus.id === id 
        ? { ...syllabus, ...updates, updated_at: new Date().toISOString() }
        : syllabus
    ));
  };

  const handleSyllabusDelete = (id: string) => {
    setSyllabi(prev => prev.filter(syllabus => syllabus.id !== id));
    // Also delete related assignments
    setAssignments(prev => prev.filter(assignment => assignment.syllabus_id !== id));
  };

  const handleAssignmentCreate = (assignmentData: Omit<Assignment, 'id' | 'created_at' | 'updated_at'>) => {
    const now = new Date().toISOString();
    const newAssignment: Assignment = {
      ...assignmentData,
      id: generateId(),
      created_at: now,
      updated_at: now
    };
    setAssignments(prev => [...prev, newAssignment]);
  };

  const handleAssignmentToggle = (id: string) => {
    setAssignments(prev => prev.map(assignment =>
      assignment.id === id
        ? { ...assignment, completed: !assignment.completed, updated_at: new Date().toISOString() }
        : assignment
    ));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <BrowserRouter>
        <Navigation />
        <Routes>
          <Route path="/" element={<Dashboard syllabi={syllabi} assignments={assignments} />} />
          <Route 
            path="/syllabi" 
            element={
              <Syllabi 
                syllabi={syllabi}
                assignments={assignments}
                onSyllabusCreate={handleSyllabusCreate}
                onSyllabusUpdate={handleSyllabusUpdate}
                onSyllabusDelete={handleSyllabusDelete}
                onAssignmentCreate={handleAssignmentCreate}
                onAssignmentToggle={handleAssignmentToggle}
              />
            } 
          />
          <Route 
            path="/calendar" 
            element={
              <CalendarView 
                assignments={assignments}
                onAssignmentToggle={handleAssignmentToggle}
              />
            } 
          />
        </Routes>
      </BrowserRouter>
    </div>
  );
};

export default App;