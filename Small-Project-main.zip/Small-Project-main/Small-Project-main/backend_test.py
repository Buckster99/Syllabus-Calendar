#!/usr/bin/env python3
"""
Backend API Testing for Syllabus and Calendar Application
Tests all CRUD operations, dashboard functionality, and data relationships
"""

import requests
import json
from datetime import date, datetime, timedelta
import sys
import traceback

# Backend URL from environment
BACKEND_URL = "https://syllabus-planner-1.preview.emergentagent.com/api"

class BackendTester:
    def __init__(self):
        self.session = requests.Session()
        self.created_syllabi = []
        self.created_assignments = []
        self.test_results = {
            "syllabus_crud": {"passed": 0, "failed": 0, "errors": []},
            "assignment_crud": {"passed": 0, "failed": 0, "errors": []},
            "dashboard_api": {"passed": 0, "failed": 0, "errors": []},
            "data_relationships": {"passed": 0, "failed": 0, "errors": []},
            "date_handling": {"passed": 0, "failed": 0, "errors": []},
            "cascading_deletes": {"passed": 0, "failed": 0, "errors": []}
        }

    def log_result(self, category, test_name, success, error_msg=None):
        """Log test result"""
        if success:
            self.test_results[category]["passed"] += 1
            print(f"✅ {test_name}")
        else:
            self.test_results[category]["failed"] += 1
            self.test_results[category]["errors"].append(f"{test_name}: {error_msg}")
            print(f"❌ {test_name}: {error_msg}")

    def test_api_health(self):
        """Test if API is accessible"""
        try:
            response = self.session.get(f"{BACKEND_URL}/")
            if response.status_code == 200:
                print("✅ API Health Check: Backend is accessible")
                return True
            else:
                print(f"❌ API Health Check: Backend returned {response.status_code}")
                return False
        except Exception as e:
            print(f"❌ API Health Check: Cannot connect to backend - {str(e)}")
            return False

    def test_syllabus_crud(self):
        """Test Syllabus CRUD operations"""
        print("\n=== Testing Syllabus CRUD Operations ===")
        
        # Test data
        syllabus_data = {
            "title": "Advanced Computer Science",
            "course_code": "CS401",
            "description": "Advanced topics in computer science including algorithms and data structures",
            "instructor": "Dr. Sarah Johnson",
            "semester": "Fall",
            "year": 2024
        }

        # Test CREATE syllabus
        try:
            response = self.session.post(f"{BACKEND_URL}/syllabi", json=syllabus_data)
            if response.status_code == 200:
                syllabus = response.json()
                self.created_syllabi.append(syllabus["id"])
                self.log_result("syllabus_crud", "Create Syllabus", True)
                
                # Verify required fields
                required_fields = ["id", "title", "course_code", "description", "instructor", "semester", "year", "created_at", "updated_at"]
                missing_fields = [field for field in required_fields if field not in syllabus]
                if missing_fields:
                    self.log_result("syllabus_crud", "Syllabus Response Fields", False, f"Missing fields: {missing_fields}")
                else:
                    self.log_result("syllabus_crud", "Syllabus Response Fields", True)
            else:
                self.log_result("syllabus_crud", "Create Syllabus", False, f"Status: {response.status_code}, Response: {response.text}")
                return
        except Exception as e:
            self.log_result("syllabus_crud", "Create Syllabus", False, str(e))
            return

        # Test READ all syllabi
        try:
            response = self.session.get(f"{BACKEND_URL}/syllabi")
            if response.status_code == 200:
                syllabi = response.json()
                if isinstance(syllabi, list) and len(syllabi) > 0:
                    self.log_result("syllabus_crud", "Get All Syllabi", True)
                else:
                    self.log_result("syllabus_crud", "Get All Syllabi", False, "No syllabi returned")
            else:
                self.log_result("syllabus_crud", "Get All Syllabi", False, f"Status: {response.status_code}")
        except Exception as e:
            self.log_result("syllabus_crud", "Get All Syllabi", False, str(e))

        # Test READ single syllabus
        if self.created_syllabi:
            try:
                syllabus_id = self.created_syllabi[0]
                response = self.session.get(f"{BACKEND_URL}/syllabi/{syllabus_id}")
                if response.status_code == 200:
                    syllabus = response.json()
                    if syllabus["id"] == syllabus_id:
                        self.log_result("syllabus_crud", "Get Single Syllabus", True)
                    else:
                        self.log_result("syllabus_crud", "Get Single Syllabus", False, "ID mismatch")
                else:
                    self.log_result("syllabus_crud", "Get Single Syllabus", False, f"Status: {response.status_code}")
            except Exception as e:
                self.log_result("syllabus_crud", "Get Single Syllabus", False, str(e))

        # Test UPDATE syllabus
        if self.created_syllabi:
            try:
                syllabus_id = self.created_syllabi[0]
                update_data = {
                    "title": "Advanced Computer Science - Updated",
                    "instructor": "Dr. Sarah Johnson-Smith"
                }
                response = self.session.put(f"{BACKEND_URL}/syllabi/{syllabus_id}", json=update_data)
                if response.status_code == 200:
                    updated_syllabus = response.json()
                    if updated_syllabus["title"] == update_data["title"] and updated_syllabus["instructor"] == update_data["instructor"]:
                        self.log_result("syllabus_crud", "Update Syllabus", True)
                    else:
                        self.log_result("syllabus_crud", "Update Syllabus", False, "Update not reflected")
                else:
                    self.log_result("syllabus_crud", "Update Syllabus", False, f"Status: {response.status_code}")
            except Exception as e:
                self.log_result("syllabus_crud", "Update Syllabus", False, str(e))

    def test_assignment_crud(self):
        """Test Assignment CRUD operations"""
        print("\n=== Testing Assignment CRUD Operations ===")
        
        # Create a syllabus first for assignments
        if not self.created_syllabi:
            syllabus_data = {
                "title": "Database Systems",
                "course_code": "CS301",
                "description": "Introduction to database design and management",
                "instructor": "Prof. Michael Chen",
                "semester": "Spring",
                "year": 2024
            }
            try:
                response = self.session.post(f"{BACKEND_URL}/syllabi", json=syllabus_data)
                if response.status_code == 200:
                    syllabus = response.json()
                    self.created_syllabi.append(syllabus["id"])
            except Exception as e:
                self.log_result("assignment_crud", "Setup Syllabus for Assignments", False, str(e))
                return

        syllabus_id = self.created_syllabi[0]
        
        # Test CREATE assignment
        assignment_data = {
            "title": "Database Design Project",
            "description": "Design and implement a relational database for a library management system",
            "due_date": (date.today() + timedelta(days=14)).isoformat(),
            "syllabus_id": syllabus_id,
            "course_code": "CS301"
        }

        try:
            response = self.session.post(f"{BACKEND_URL}/assignments", json=assignment_data)
            if response.status_code == 200:
                assignment = response.json()
                self.created_assignments.append(assignment["id"])
                self.log_result("assignment_crud", "Create Assignment", True)
                
                # Verify required fields
                required_fields = ["id", "title", "description", "due_date", "syllabus_id", "course_code", "completed", "created_at", "updated_at"]
                missing_fields = [field for field in required_fields if field not in assignment]
                if missing_fields:
                    self.log_result("assignment_crud", "Assignment Response Fields", False, f"Missing fields: {missing_fields}")
                else:
                    self.log_result("assignment_crud", "Assignment Response Fields", True)
            else:
                self.log_result("assignment_crud", "Create Assignment", False, f"Status: {response.status_code}, Response: {response.text}")
                return
        except Exception as e:
            self.log_result("assignment_crud", "Create Assignment", False, str(e))
            return

        # Test READ all assignments
        try:
            response = self.session.get(f"{BACKEND_URL}/assignments")
            if response.status_code == 200:
                assignments = response.json()
                if isinstance(assignments, list) and len(assignments) > 0:
                    self.log_result("assignment_crud", "Get All Assignments", True)
                else:
                    self.log_result("assignment_crud", "Get All Assignments", False, "No assignments returned")
            else:
                self.log_result("assignment_crud", "Get All Assignments", False, f"Status: {response.status_code}")
        except Exception as e:
            self.log_result("assignment_crud", "Get All Assignments", False, str(e))

        # Test READ assignments by syllabus
        try:
            response = self.session.get(f"{BACKEND_URL}/assignments/syllabus/{syllabus_id}")
            if response.status_code == 200:
                assignments = response.json()
                if isinstance(assignments, list):
                    self.log_result("assignment_crud", "Get Assignments by Syllabus", True)
                else:
                    self.log_result("assignment_crud", "Get Assignments by Syllabus", False, "Invalid response format")
            else:
                self.log_result("assignment_crud", "Get Assignments by Syllabus", False, f"Status: {response.status_code}")
        except Exception as e:
            self.log_result("assignment_crud", "Get Assignments by Syllabus", False, str(e))

        # Test UPDATE assignment (toggle completion)
        if self.created_assignments:
            try:
                assignment_id = self.created_assignments[0]
                update_data = {"completed": True}
                response = self.session.put(f"{BACKEND_URL}/assignments/{assignment_id}", json=update_data)
                if response.status_code == 200:
                    updated_assignment = response.json()
                    if updated_assignment["completed"] == True:
                        self.log_result("assignment_crud", "Update Assignment Completion", True)
                    else:
                        self.log_result("assignment_crud", "Update Assignment Completion", False, "Completion status not updated")
                else:
                    self.log_result("assignment_crud", "Update Assignment Completion", False, f"Status: {response.status_code}")
            except Exception as e:
                self.log_result("assignment_crud", "Update Assignment Completion", False, str(e))

    def test_dashboard_api(self):
        """Test Dashboard API functionality"""
        print("\n=== Testing Dashboard API ===")
        
        # Create test data for dashboard
        self.create_test_data_for_dashboard()
        
        try:
            response = self.session.get(f"{BACKEND_URL}/dashboard")
            if response.status_code == 200:
                dashboard = response.json()
                
                # Check required fields
                required_fields = ["total_syllabi", "total_assignments", "completed_assignments", "pending_assignments", "upcoming_assignments", "overdue_assignments"]
                missing_fields = [field for field in required_fields if field not in dashboard]
                
                if missing_fields:
                    self.log_result("dashboard_api", "Dashboard Response Fields", False, f"Missing fields: {missing_fields}")
                else:
                    self.log_result("dashboard_api", "Dashboard Response Fields", True)
                
                # Verify stats are numbers
                numeric_fields = ["total_syllabi", "total_assignments", "completed_assignments", "pending_assignments"]
                for field in numeric_fields:
                    if isinstance(dashboard.get(field), int):
                        self.log_result("dashboard_api", f"Dashboard {field} Type", True)
                    else:
                        self.log_result("dashboard_api", f"Dashboard {field} Type", False, f"Expected int, got {type(dashboard.get(field))}")
                
                # Verify arrays
                array_fields = ["upcoming_assignments", "overdue_assignments"]
                for field in array_fields:
                    if isinstance(dashboard.get(field), list):
                        self.log_result("dashboard_api", f"Dashboard {field} Type", True)
                    else:
                        self.log_result("dashboard_api", f"Dashboard {field} Type", False, f"Expected list, got {type(dashboard.get(field))}")
                
            else:
                self.log_result("dashboard_api", "Dashboard API Call", False, f"Status: {response.status_code}")
        except Exception as e:
            self.log_result("dashboard_api", "Dashboard API Call", False, str(e))

    def test_upcoming_assignments(self):
        """Test upcoming assignments endpoint"""
        try:
            response = self.session.get(f"{BACKEND_URL}/assignments/upcoming")
            if response.status_code == 200:
                upcoming = response.json()
                if isinstance(upcoming, list):
                    self.log_result("dashboard_api", "Upcoming Assignments Endpoint", True)
                else:
                    self.log_result("dashboard_api", "Upcoming Assignments Endpoint", False, "Invalid response format")
            else:
                self.log_result("dashboard_api", "Upcoming Assignments Endpoint", False, f"Status: {response.status_code}")
        except Exception as e:
            self.log_result("dashboard_api", "Upcoming Assignments Endpoint", False, str(e))

    def test_date_handling(self):
        """Test date serialization and deserialization"""
        print("\n=== Testing Date Handling ===")
        
        if not self.created_syllabi:
            return
            
        # Test with various date formats
        test_dates = [
            (date.today() + timedelta(days=1)).isoformat(),  # Tomorrow
            (date.today() + timedelta(days=30)).isoformat(), # Next month
            (date.today() - timedelta(days=1)).isoformat(),  # Yesterday (overdue)
        ]
        
        syllabus_id = self.created_syllabi[0]
        
        for i, test_date in enumerate(test_dates):
            assignment_data = {
                "title": f"Date Test Assignment {i+1}",
                "description": f"Testing date handling with date: {test_date}",
                "due_date": test_date,
                "syllabus_id": syllabus_id,
                "course_code": "TEST101"
            }
            
            try:
                response = self.session.post(f"{BACKEND_URL}/assignments", json=assignment_data)
                if response.status_code == 200:
                    assignment = response.json()
                    self.created_assignments.append(assignment["id"])
                    
                    # Verify date is properly handled
                    if "due_date" in assignment:
                        self.log_result("date_handling", f"Date Serialization Test {i+1}", True)
                    else:
                        self.log_result("date_handling", f"Date Serialization Test {i+1}", False, "due_date missing from response")
                else:
                    self.log_result("date_handling", f"Date Serialization Test {i+1}", False, f"Status: {response.status_code}")
            except Exception as e:
                self.log_result("date_handling", f"Date Serialization Test {i+1}", False, str(e))

    def test_data_relationships(self):
        """Test data relationships between syllabi and assignments"""
        print("\n=== Testing Data Relationships ===")
        
        if not self.created_syllabi:
            return
            
        syllabus_id = self.created_syllabi[0]
        
        # Test creating assignment with invalid syllabus_id
        invalid_assignment_data = {
            "title": "Invalid Syllabus Test",
            "description": "This should fail due to invalid syllabus_id",
            "due_date": (date.today() + timedelta(days=7)).isoformat(),
            "syllabus_id": "invalid-syllabus-id",
            "course_code": "INVALID"
        }
        
        try:
            response = self.session.post(f"{BACKEND_URL}/assignments", json=invalid_assignment_data)
            if response.status_code == 404:
                self.log_result("data_relationships", "Invalid Syllabus ID Validation", True)
            else:
                self.log_result("data_relationships", "Invalid Syllabus ID Validation", False, f"Expected 404, got {response.status_code}")
        except Exception as e:
            self.log_result("data_relationships", "Invalid Syllabus ID Validation", False, str(e))
        
        # Test that assignments are linked to correct syllabus
        try:
            response = self.session.get(f"{BACKEND_URL}/assignments/syllabus/{syllabus_id}")
            if response.status_code == 200:
                assignments = response.json()
                if isinstance(assignments, list):
                    # Check that all assignments belong to the correct syllabus
                    all_correct = all(assignment.get("syllabus_id") == syllabus_id for assignment in assignments)
                    if all_correct:
                        self.log_result("data_relationships", "Assignment-Syllabus Relationship", True)
                    else:
                        self.log_result("data_relationships", "Assignment-Syllabus Relationship", False, "Some assignments have incorrect syllabus_id")
                else:
                    self.log_result("data_relationships", "Assignment-Syllabus Relationship", False, "Invalid response format")
            else:
                self.log_result("data_relationships", "Assignment-Syllabus Relationship", False, f"Status: {response.status_code}")
        except Exception as e:
            self.log_result("data_relationships", "Assignment-Syllabus Relationship", False, str(e))

    def test_cascading_deletes(self):
        """Test that deleting a syllabus also deletes related assignments"""
        print("\n=== Testing Cascading Deletes ===")
        
        # Create a new syllabus specifically for this test
        test_syllabus_data = {
            "title": "Test Syllabus for Deletion",
            "course_code": "DELETE101",
            "description": "This syllabus will be deleted to test cascading",
            "instructor": "Test Instructor",
            "semester": "Test",
            "year": 2024
        }
        
        try:
            # Create syllabus
            response = self.session.post(f"{BACKEND_URL}/syllabi", json=test_syllabus_data)
            if response.status_code != 200:
                self.log_result("cascading_deletes", "Setup Test Syllabus", False, f"Status: {response.status_code}")
                return
                
            test_syllabus = response.json()
            test_syllabus_id = test_syllabus["id"]
            
            # Create assignment for this syllabus
            test_assignment_data = {
                "title": "Test Assignment for Deletion",
                "description": "This assignment should be deleted with its syllabus",
                "due_date": (date.today() + timedelta(days=7)).isoformat(),
                "syllabus_id": test_syllabus_id,
                "course_code": "DELETE101"
            }
            
            response = self.session.post(f"{BACKEND_URL}/assignments", json=test_assignment_data)
            if response.status_code != 200:
                self.log_result("cascading_deletes", "Setup Test Assignment", False, f"Status: {response.status_code}")
                return
                
            test_assignment = response.json()
            test_assignment_id = test_assignment["id"]
            
            # Verify assignment exists
            response = self.session.get(f"{BACKEND_URL}/assignments/syllabus/{test_syllabus_id}")
            if response.status_code == 200:
                assignments = response.json()
                if len(assignments) > 0:
                    self.log_result("cascading_deletes", "Verify Assignment Exists Before Delete", True)
                else:
                    self.log_result("cascading_deletes", "Verify Assignment Exists Before Delete", False, "No assignments found")
                    return
            else:
                self.log_result("cascading_deletes", "Verify Assignment Exists Before Delete", False, f"Status: {response.status_code}")
                return
            
            # Delete the syllabus
            response = self.session.delete(f"{BACKEND_URL}/syllabi/{test_syllabus_id}")
            if response.status_code == 200:
                self.log_result("cascading_deletes", "Delete Syllabus", True)
                
                # Verify assignments are also deleted
                response = self.session.get(f"{BACKEND_URL}/assignments/syllabus/{test_syllabus_id}")
                if response.status_code == 200:
                    assignments = response.json()
                    if len(assignments) == 0:
                        self.log_result("cascading_deletes", "Verify Assignments Deleted", True)
                    else:
                        self.log_result("cascading_deletes", "Verify Assignments Deleted", False, f"Found {len(assignments)} assignments still exist")
                else:
                    self.log_result("cascading_deletes", "Verify Assignments Deleted", False, f"Status: {response.status_code}")
            else:
                self.log_result("cascading_deletes", "Delete Syllabus", False, f"Status: {response.status_code}")
                
        except Exception as e:
            self.log_result("cascading_deletes", "Cascading Delete Test", False, str(e))

    def create_test_data_for_dashboard(self):
        """Create diverse test data for dashboard testing"""
        # Create additional syllabi if needed
        if len(self.created_syllabi) < 2:
            additional_syllabi = [
                {
                    "title": "Web Development",
                    "course_code": "CS201",
                    "description": "Modern web development with React and Node.js",
                    "instructor": "Prof. Lisa Wang",
                    "semester": "Fall",
                    "year": 2024
                },
                {
                    "title": "Machine Learning",
                    "course_code": "CS501",
                    "description": "Introduction to machine learning algorithms",
                    "instructor": "Dr. Robert Kim",
                    "semester": "Spring",
                    "year": 2024
                }
            ]
            
            for syllabus_data in additional_syllabi:
                try:
                    response = self.session.post(f"{BACKEND_URL}/syllabi", json=syllabus_data)
                    if response.status_code == 200:
                        syllabus = response.json()
                        self.created_syllabi.append(syllabus["id"])
                except Exception as e:
                    print(f"Warning: Could not create additional syllabus: {e}")
        
        # Create assignments with different due dates and completion status
        if self.created_syllabi:
            test_assignments = [
                {
                    "title": "Overdue Assignment",
                    "description": "This assignment is overdue",
                    "due_date": (date.today() - timedelta(days=5)).isoformat(),
                    "completed": False
                },
                {
                    "title": "Due Today",
                    "description": "This assignment is due today",
                    "due_date": date.today().isoformat(),
                    "completed": False
                },
                {
                    "title": "Upcoming Assignment",
                    "description": "This assignment is due next week",
                    "due_date": (date.today() + timedelta(days=7)).isoformat(),
                    "completed": False
                },
                {
                    "title": "Completed Assignment",
                    "description": "This assignment is completed",
                    "due_date": (date.today() + timedelta(days=3)).isoformat(),
                    "completed": True
                }
            ]
            
            for i, assignment_data in enumerate(test_assignments):
                syllabus_id = self.created_syllabi[i % len(self.created_syllabi)]
                assignment_data.update({
                    "syllabus_id": syllabus_id,
                    "course_code": f"TEST{i+1:03d}"
                })
                
                try:
                    response = self.session.post(f"{BACKEND_URL}/assignments", json=assignment_data)
                    if response.status_code == 200:
                        assignment = response.json()
                        self.created_assignments.append(assignment["id"])
                        
                        # Update completion status if needed
                        if assignment_data.get("completed"):
                            update_response = self.session.put(
                                f"{BACKEND_URL}/assignments/{assignment['id']}", 
                                json={"completed": True}
                            )
                except Exception as e:
                    print(f"Warning: Could not create test assignment: {e}")

    def cleanup_test_data(self):
        """Clean up created test data"""
        print("\n=== Cleaning up test data ===")
        
        # Delete assignments first
        for assignment_id in self.created_assignments:
            try:
                response = self.session.delete(f"{BACKEND_URL}/assignments/{assignment_id}")
                if response.status_code == 200:
                    print(f"✅ Deleted assignment {assignment_id}")
                else:
                    print(f"⚠️ Could not delete assignment {assignment_id}: {response.status_code}")
            except Exception as e:
                print(f"⚠️ Error deleting assignment {assignment_id}: {e}")
        
        # Delete syllabi (this should also cascade delete any remaining assignments)
        for syllabus_id in self.created_syllabi:
            try:
                response = self.session.delete(f"{BACKEND_URL}/syllabi/{syllabus_id}")
                if response.status_code == 200:
                    print(f"✅ Deleted syllabus {syllabus_id}")
                else:
                    print(f"⚠️ Could not delete syllabus {syllabus_id}: {response.status_code}")
            except Exception as e:
                print(f"⚠️ Error deleting syllabus {syllabus_id}: {e}")

    def print_summary(self):
        """Print test summary"""
        print("\n" + "="*60)
        print("BACKEND API TEST SUMMARY")
        print("="*60)
        
        total_passed = 0
        total_failed = 0
        
        for category, results in self.test_results.items():
            passed = results["passed"]
            failed = results["failed"]
            total_passed += passed
            total_failed += failed
            
            status = "✅ PASS" if failed == 0 else "❌ FAIL"
            print(f"{category.replace('_', ' ').title()}: {status} ({passed} passed, {failed} failed)")
            
            if results["errors"]:
                for error in results["errors"]:
                    print(f"  - {error}")
        
        print("-" * 60)
        print(f"OVERALL: {total_passed} passed, {total_failed} failed")
        
        if total_failed == 0:
            print("🎉 ALL BACKEND TESTS PASSED!")
        else:
            print(f"⚠️ {total_failed} TESTS FAILED - NEEDS ATTENTION")
        
        return total_failed == 0

    def run_all_tests(self):
        """Run all backend tests"""
        print("Starting Backend API Tests...")
        print(f"Testing against: {BACKEND_URL}")
        
        # Check API health first
        if not self.test_api_health():
            print("❌ Cannot proceed with tests - API is not accessible")
            return False
        
        try:
            # Run all test categories
            self.test_syllabus_crud()
            self.test_assignment_crud()
            self.test_dashboard_api()
            self.test_upcoming_assignments()
            self.test_date_handling()
            self.test_data_relationships()
            self.test_cascading_deletes()
            
            # Print summary
            success = self.print_summary()
            
            return success
            
        except Exception as e:
            print(f"❌ Critical error during testing: {e}")
            traceback.print_exc()
            return False
        finally:
            # Always cleanup
            self.cleanup_test_data()

if __name__ == "__main__":
    tester = BackendTester()
    success = tester.run_all_tests()
    sys.exit(0 if success else 1)