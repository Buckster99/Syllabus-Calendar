from fastapi import FastAPI, APIRouter, HTTPException
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional
import uuid
from datetime import datetime, timezone, date

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Helper functions for MongoDB serialization
def prepare_for_mongo(data):
    if isinstance(data.get('due_date'), date):
        data['due_date'] = data['due_date'].isoformat()
    if isinstance(data.get('created_at'), datetime):
        data['created_at'] = data['created_at'].isoformat()
    if isinstance(data.get('updated_at'), datetime):
        data['updated_at'] = data['updated_at'].isoformat()
    return data

def parse_from_mongo(item):
    if isinstance(item.get('due_date'), str):
        item['due_date'] = datetime.fromisoformat(item['due_date']).date()
    if isinstance(item.get('created_at'), str):
        item['created_at'] = datetime.fromisoformat(item['created_at'])
    if isinstance(item.get('updated_at'), str):
        item['updated_at'] = datetime.fromisoformat(item['updated_at'])
    return item

# Define Models
class Syllabus(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    course_code: str
    description: str
    instructor: str
    semester: str
    year: int
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class SyllabusCreate(BaseModel):
    title: str
    course_code: str
    description: str
    instructor: str
    semester: str
    year: int

class SyllabusUpdate(BaseModel):
    title: Optional[str] = None
    course_code: Optional[str] = None
    description: Optional[str] = None
    instructor: Optional[str] = None
    semester: Optional[str] = None
    year: Optional[int] = None

class Assignment(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    description: str
    due_date: date
    syllabus_id: str
    course_code: str
    completed: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class AssignmentCreate(BaseModel):
    title: str
    description: str
    due_date: date
    syllabus_id: str
    course_code: str

class AssignmentUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    due_date: Optional[date] = None
    completed: Optional[bool] = None

# Basic route
@api_router.get("/")
async def root():
    return {"message": "Syllabus and Calendar API"}

# Syllabus routes
@api_router.post("/syllabi", response_model=Syllabus)
async def create_syllabus(syllabus: SyllabusCreate):
    syllabus_dict = syllabus.dict()
    syllabus_obj = Syllabus(**syllabus_dict)
    syllabus_data = prepare_for_mongo(syllabus_obj.dict())
    await db.syllabi.insert_one(syllabus_data)
    return syllabus_obj

@api_router.get("/syllabi", response_model=List[Syllabus])
async def get_syllabi():
    syllabi = await db.syllabi.find().to_list(1000)
    return [Syllabus(**parse_from_mongo(syllabus)) for syllabus in syllabi]

@api_router.get("/syllabi/{syllabus_id}", response_model=Syllabus)
async def get_syllabus(syllabus_id: str):
    syllabus = await db.syllabi.find_one({"id": syllabus_id})
    if not syllabus:
        raise HTTPException(status_code=404, detail="Syllabus not found")
    return Syllabus(**parse_from_mongo(syllabus))

@api_router.put("/syllabi/{syllabus_id}", response_model=Syllabus)
async def update_syllabus(syllabus_id: str, syllabus_update: SyllabusUpdate):
    update_data = {k: v for k, v in syllabus_update.dict().items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="No fields to update")
    
    update_data["updated_at"] = datetime.now(timezone.utc)
    update_data = prepare_for_mongo(update_data)
    
    result = await db.syllabi.update_one({"id": syllabus_id}, {"$set": update_data})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Syllabus not found")
    
    updated_syllabus = await db.syllabi.find_one({"id": syllabus_id})
    return Syllabus(**parse_from_mongo(updated_syllabus))

@api_router.delete("/syllabi/{syllabus_id}")
async def delete_syllabus(syllabus_id: str):
    result = await db.syllabi.delete_one({"id": syllabus_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Syllabus not found")
    
    # Also delete related assignments
    await db.assignments.delete_many({"syllabus_id": syllabus_id})
    return {"message": "Syllabus and related assignments deleted successfully"}

# Assignment routes
@api_router.post("/assignments", response_model=Assignment)
async def create_assignment(assignment: AssignmentCreate):
    # Verify syllabus exists
    syllabus = await db.syllabi.find_one({"id": assignment.syllabus_id})
    if not syllabus:
        raise HTTPException(status_code=404, detail="Syllabus not found")
    
    assignment_dict = assignment.dict()
    assignment_obj = Assignment(**assignment_dict)
    assignment_data = prepare_for_mongo(assignment_obj.dict())
    await db.assignments.insert_one(assignment_data)
    return assignment_obj

@api_router.get("/assignments", response_model=List[Assignment])
async def get_assignments():
    assignments = await db.assignments.find().to_list(1000)
    return [Assignment(**parse_from_mongo(assignment)) for assignment in assignments]

@api_router.get("/assignments/syllabus/{syllabus_id}", response_model=List[Assignment])
async def get_assignments_by_syllabus(syllabus_id: str):
    assignments = await db.assignments.find({"syllabus_id": syllabus_id}).to_list(1000)
    return [Assignment(**parse_from_mongo(assignment)) for assignment in assignments]

@api_router.get("/assignments/upcoming")
async def get_upcoming_assignments():
    today = date.today()
    assignments = await db.assignments.find().to_list(1000)
    upcoming = []
    for assignment in assignments:
        parsed_assignment = parse_from_mongo(assignment)
        if parsed_assignment.get('due_date') and parsed_assignment['due_date'] >= today:
            upcoming.append(Assignment(**parsed_assignment))
    
    # Sort by due date
    upcoming_sorted = sorted(upcoming, key=lambda x: x.due_date)
    return upcoming_sorted[:10]  # Return next 10 upcoming assignments

@api_router.put("/assignments/{assignment_id}", response_model=Assignment)
async def update_assignment(assignment_id: str, assignment_update: AssignmentUpdate):
    update_data = {k: v for k, v in assignment_update.dict().items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="No fields to update")
    
    update_data["updated_at"] = datetime.now(timezone.utc)
    update_data = prepare_for_mongo(update_data)
    
    result = await db.assignments.update_one({"id": assignment_id}, {"$set": update_data})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Assignment not found")
    
    updated_assignment = await db.assignments.find_one({"id": assignment_id})
    return Assignment(**parse_from_mongo(updated_assignment))

@api_router.delete("/assignments/{assignment_id}")
async def delete_assignment(assignment_id: str):
    result = await db.assignments.delete_one({"id": assignment_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Assignment not found")
    return {"message": "Assignment deleted successfully"}

# Dashboard route
@api_router.get("/dashboard")
async def get_dashboard():
    total_syllabi = await db.syllabi.count_documents({})
    total_assignments = await db.assignments.count_documents({})
    completed_assignments = await db.assignments.count_documents({"completed": True})
    
    # Get upcoming assignments
    today = date.today()
    assignments = await db.assignments.find().to_list(1000)
    upcoming = []
    overdue = []
    
    for assignment in assignments:
        parsed_assignment = parse_from_mongo(assignment)
        if parsed_assignment.get('due_date'):
            if parsed_assignment['due_date'] >= today:
                upcoming.append(Assignment(**parsed_assignment))
            else:
                if not parsed_assignment.get('completed', False):
                    overdue.append(Assignment(**parsed_assignment))
    
    upcoming_sorted = sorted(upcoming, key=lambda x: x.due_date)[:5]
    overdue_sorted = sorted(overdue, key=lambda x: x.due_date, reverse=True)[:5]
    
    return {
        "total_syllabi": total_syllabi,
        "total_assignments": total_assignments,
        "completed_assignments": completed_assignments,
        "pending_assignments": total_assignments - completed_assignments,
        "upcoming_assignments": upcoming_sorted,
        "overdue_assignments": overdue_sorted
    }

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()